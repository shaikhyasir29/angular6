import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../_service';
import { userMaster } from '../_module';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['../header/bootstrap.min.css']
})
export class HeaderComponent implements OnInit {
  currentUser: userMaster;

  isLoggedIn$: Observable<boolean>;

  constructor(private authService: AuthenticationService) { }

  validSession(){

    return this.authService.checkSessionUser();
  }

  ngOnInit() {
    this.isLoggedIn$ = this.authService.isLoggedIn;
  }

  onLogout() {
    this.authService.logout();
  }

}
