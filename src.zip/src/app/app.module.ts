import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule }    from '@angular/forms';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppComponent } from './app.component';

import { routing }        from './app.routing';
import { AuthGuard } from './_guards';
import { AlertService, AuthenticationService, UserMasterService } from './_service';
import { HomeComponent } from './home';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    LoginComponent

  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    routing

  ],
  providers: [
    AuthGuard,
    AlertService,
    AuthenticationService,
    UserMasterService

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
