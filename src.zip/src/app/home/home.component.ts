import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { userMaster } from '../_module';
import { UserMasterService } from '../_service';

@Component({
  selector: 'app-home',
  template: '<p>Yay! You are logged in!</p>',
  //templateUrl: 'home.component.html',
  styles: []
})
export class HomeComponent {}
// @Component({templateUrl: 'home.component.html'})

// export class HomeComponent implements OnInit {

//     currentUser: userMaster;
//     users: userMaster[] = [];

//     constructor(private userService: UserMasterService) {
//         this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
//     }

//     ngOnInit() {

//     }
// }
