import {Injectable} from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {HttpClient,HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import {userMaster} from '../_module';



const httpOptions  = {
  headers: new HttpHeaders({ 'Content-Type' : 'application/json'
  })
};

    // httpOptions.headers.append('Access-Control-Allow-Origin', '*');
    // httpOptions.headers.append('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    // httpOptions.headers.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // httpOptions.headers.append('Access-Control-Allow-Credentials', 'true');


@Injectable()
export class AuthenticationService{
  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);


    constructor(private http:HttpClient){}

    get isLoggedIn() {
      return this.loggedIn.asObservable();
    }

    checkSessionUser(){
      this.currentUser = JSON.parse(localStorage.getItem('currentUser'));

      if(this.currentUser.LOGIN_ID !=""){
        return true;

      }else{
        return false;

      }
    }

     login(username: string, password: string) {
      const postedData = { username: username, password: password };
      //const headers = new HttpHeaders().set('content-type', 'application/json');

      return this.http.post<any>('http://localhost:54811/api/User/authenticate?username='+username+'&password='+password, postedData  )
            .pipe(map(User => {
                // login successful if there's a jwt token in the response
                if (User && User.USER_ID) {
                    this.loggedIn.next(true);
                  // store user details and jwt token in local storage to keep user logged in between page refreshes
                    localStorage.setItem('currentUser', JSON.stringify(User));
                }

                return User;
            }));

    }
    logout(){
       this.loggedIn.next(false);
        localStorage.removeItem("currentUser");
    }

}
