import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';

import { userMaster } from '../_module'

@Injectable()
export class UserMasterService{
constructor(private http: HttpClient) { }
    getAll() {
        return this.http.get<userMaster[]>(`/users`);
    }

    getById(id: number) {
        return this.http.get(`/users/` + id);
    }

    register(user: userMaster) {
        return this.http.post(`/users/register`, user);
    }

    update(user: userMaster) {
        return this.http.put(`/users/` + user.USER_ID, user);
    }

    delete(id: number) {
        return this.http.delete(`/users/` + id);
    }

  }
