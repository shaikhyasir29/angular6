export class userMaster{
id:number;
USER_ID: number;
FIRST_NAME: string;
LAST_NAME: string;
LOGIN_ID: string;
EMAIL_ID: string;
PASSWORD: string;
IS_ACTIVE:number;
}