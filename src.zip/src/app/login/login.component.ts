import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';


import { AlertService,AuthenticationService } from '../_service';

@Component({
  templateUrl: 'login.component.html',
  styleUrls:['./login-4.min.css']
})
export class  LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;


  constructor(
      private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private alertService: AlertService
    ) {}

    ngOnInit(): void {
        //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
        //Add 'implements OnInit' to the class.
        this.loginForm = this.formBuilder.group({
            LOGIN_ID:['',Validators.required],
            PASSWORD:['',Validators.required]
        })

        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    get f(){ return this.loginForm.controls; }

    onSubmit(){
        this.submitted = true;

        //stop here if form not valid
        if(this.loginForm.invalid){
            return;
        }
        this.loading = true;

        this.authenticationService.login(
            this.f.LOGIN_ID.value,this.f.PASSWORD.value
        ).pipe(first())
        .subscribe(
               data => {
                   this.router.navigate([this.returnUrl]);
               } ,
               error => {
                   this.alertService.error(error);
                   this.loading = false;
            });

    }

}
