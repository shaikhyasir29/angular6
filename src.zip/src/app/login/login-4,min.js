import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  'login': {
    'backgroundColor': '#025abc !important'
  },
  'login logo': {
    'margin': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }, { 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }],
    'padding': [{ 'unit': 'px', 'value': 15 }, { 'unit': 'px', 'value': 15 }, { 'unit': 'px', 'value': 15 }, { 'unit': 'px', 'value': 15 }],
    'textAlign': 'center',
    '<w480': {
      'marginTop': [{ 'unit': 'px', 'value': 10 }]
    }
  },
  'login content': {
    // background: url(../img/bg-white-lock.png);
    'width': [{ 'unit': 'px', 'value': 360 }],
    'margin': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }, { 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }],
    'padding': [{ 'unit': 'px', 'value': 20 }, { 'unit': 'px', 'value': 30 }, { 'unit': 'px', 'value': 15 }, { 'unit': 'px', 'value': 30 }],
    'WebkitBorderRadius': '7px',
    'MozBorderRadius': '7px',
    'MsBorderRadius': '7px',
    'OBorderRadius': '7px',
    'borderRadius': '7px'
  },
  'login content h3': {
    'color': '#eee'
  },
  'login content h4': {
    'color': '#eee'
  },
  'login content label': {
    'color': '#fff'
  },
  'login content p': {
    'color': '#fff'
  },
  'login mt-checkbox>span:after': {
    'borderColor': '#eee'
  },
  'login content forget-form': {
    'padding': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }],
    'margin': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }]
  },
  'login content login-form': {
    'padding': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }],
    'margin': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 0 }]
  },
  'login content form-control': {
    'backgroundColor': '#fff'
  },
  'login content forget-form': {
    'display': 'none'
  },
  'login content register-form': {
    'display': 'none'
  },
  'login content form-title': {
    'fontWeight': '300',
    'marginBottom': [{ 'unit': 'px', 'value': 25 }]
  },
  'login content form-actions': {
    'backgroundColor': 'transparent',
    'clear': 'both',
    'border': [{ 'unit': 'px', 'value': 0 }],
    'padding': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': 30 }, { 'unit': 'px', 'value': 25 }, { 'unit': 'px', 'value': 30 }],
    'marginLeft': [{ 'unit': 'px', 'value': -30 }],
    'marginRight': [{ 'unit': 'px', 'value': -30 }]
  },
  'login content forget-form form-actions': {
    'border': [{ 'unit': 'px', 'value': 0 }],
    'marginBottom': [{ 'unit': 'px', 'value': 0 }],
    'paddingBottom': [{ 'unit': 'px', 'value': 20 }]
  },
  'login content register-form form-actions': {
    'border': [{ 'unit': 'px', 'value': 0 }],
    'marginBottom': [{ 'unit': 'px', 'value': 0 }],
    'paddingBottom': [{ 'unit': 'px', 'value': 0 }]
  },
  'login content form-actions rememberme': {
    'marginTop': [{ 'unit': 'px', 'value': 8 }],
    'display': 'inline-block'
  },
  'login content form-actions btn': {
    'marginTop': [{ 'unit': 'px', 'value': 1 }]
  },
  'login content forget-password': {
    'marginTop': [{ 'unit': 'px', 'value': 25 }]
  },
  'login content create-account': {
    'borderTop': [{ 'unit': 'px', 'value': 1 }, { 'unit': 'string', 'value': 'dotted' }, { 'unit': 'string', 'value': '#eee' }],
    'paddingTop': [{ 'unit': 'px', 'value': 10 }],
    'marginTop': [{ 'unit': 'px', 'value': 0 }]
  },
  'login content create-account a': {
    'display': 'inline-block',
    'marginTop': [{ 'unit': 'px', 'value': 5 }]
  },
  'login content select2-container i': {
    'display': 'inline-block',
    'position': 'relative',
    'color': '#ccc',
    'zIndex': '1',
    'top': [{ 'unit': 'px', 'value': 1 }],
    'margin': [{ 'unit': 'px', 'value': 4 }, { 'unit': 'px', 'value': 4 }, { 'unit': 'px', 'value': 0 }, { 'unit': 'px', 'value': -1 }],
    'width': [{ 'unit': 'px', 'value': 16 }],
    'height': [{ 'unit': 'px', 'value': 16 }],
    'fontSize': [{ 'unit': 'px', 'value': 16 }],
    'textAlign': 'center'
  },
  'login content has-error select2-container i': {
    'color': '#b94a48'
  },
  'login content select2-container a span': {
    'fontSize': [{ 'unit': 'px', 'value': 13 }]
  },
  'login content select2-container a span img': {
    'marginLeft': [{ 'unit': 'px', 'value': 4 }]
  },
  'login copyright': {
    'textAlign': 'center',
    'margin': [{ 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }, { 'unit': 'px', 'value': 0 }, { 'unit': 'string', 'value': 'auto' }],
    'padding': [{ 'unit': 'px', 'value': 10 }, { 'unit': 'px', 'value': 10 }, { 'unit': 'px', 'value': 10 }, { 'unit': 'px', 'value': 10 }],
    'color': '#eee',
    'fontSize': [{ 'unit': 'px', 'value': 13 }]
  }
});
